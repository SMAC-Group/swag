## swag 0.1.0

- First version for submission to CRAN. The package is made available on GitHub ([github.com/SMAC-Group/SWAG-R-Package/](https://github.com/SMAC-Group/SWAG-R-Package/))
